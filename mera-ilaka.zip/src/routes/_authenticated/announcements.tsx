import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus } from "lucide-react";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";

export const Route = createFileRoute("/_authenticated/announcements")({
  head: () => ({ meta: [{ title: "Announcements — Mera Ilaka" }] }),
  component: Announcements,
});

function Announcements() {
  const qc = useQueryClient();
  const [isAdmin, setIsAdmin] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    (async () => {
      const { data } = await supabase.auth.getUser();
      if (!data.user) return;
      const { data: roles } = await supabase.from("user_roles").select("role").eq("user_id", data.user.id);
      setIsAdmin(!!roles?.some((r) => r.role === "admin"));
    })();
  }, []);

  const { data, isLoading } = useQuery({
    queryKey: ["announcements"],
    queryFn: async () => {
      const { data, error } = await supabase.from("announcements").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const create = useMutation({
    mutationFn: async (payload: { title: string; body: string; area: string }) => {
      const { data: u } = await supabase.auth.getUser();
      const { error } = await supabase.from("announcements").insert({ ...payload, posted_by: u.user!.id });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Announcement posted");
      qc.invalidateQueries({ queryKey: ["announcements"] });
      setOpen(false);
    },
    onError: (e) => toast.error(e.message),
  });

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Announcements</h1>
          <p className="text-muted-foreground">Latest notices from your community.</p>
        </div>
        {isAdmin && (
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button><Plus className="mr-2 h-4 w-4" />New</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Post announcement</DialogTitle></DialogHeader>
              <form className="space-y-3" onSubmit={(e) => {
                e.preventDefault();
                const fd = new FormData(e.currentTarget);
                create.mutate({ title: String(fd.get("title")), body: String(fd.get("body")), area: String(fd.get("area")) });
              }}>
                <div><Label>Title</Label><Input name="title" required /></div>
                <div><Label>Area (optional)</Label><Input name="area" /></div>
                <div><Label>Body</Label><Textarea name="body" required rows={5} /></div>
                <Button type="submit" className="w-full" disabled={create.isPending}>Post</Button>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {isLoading && <p className="text-muted-foreground">Loading…</p>}
      {data?.length === 0 && <p className="text-muted-foreground">No announcements yet.</p>}
      <div className="space-y-3">
        {data?.map((a) => (
          <Card key={a.id}>
            <CardHeader>
              <CardTitle>{a.title}</CardTitle>
              <p className="text-xs text-muted-foreground">
                {a.area ? `${a.area} • ` : ""}{formatDistanceToNow(new Date(a.created_at), { addSuffix: true })}
              </p>
            </CardHeader>
            <CardContent><p className="whitespace-pre-wrap text-sm">{a.body}</p></CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}