import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Phone, MapPin } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/businesses")({
  head: () => ({ meta: [{ title: "Businesses — Mera Ilaka" }] }),
  component: Businesses,
});

function Businesses() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");

  const { data } = useQuery({
    queryKey: ["businesses"],
    queryFn: async () => {
      const { data, error } = await supabase.from("businesses").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const create = useMutation({
    mutationFn: async (p: Record<string, string>) => {
      const { data: u } = await supabase.auth.getUser();
      const { error } = await supabase.from("businesses").insert({
        owner_id: u.user!.id,
        name: p.name, category: p.category,
        area: p.area || null, phone: p.phone || null,
        address: p.address || null, description: p.description || null,
      });
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Business added"); qc.invalidateQueries({ queryKey: ["businesses"] }); setOpen(false); },
    onError: (e) => toast.error(e.message),
  });

  const filtered = data?.filter((b) => (b.name + " " + b.category + " " + (b.area ?? "")).toLowerCase().includes(q.toLowerCase()));

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-3xl font-bold">Business Directory</h1>
          <p className="text-muted-foreground">Discover local shops and services.</p>
        </div>
        <div className="flex gap-2">
          <Input placeholder="Search…" value={q} onChange={(e) => setQ(e.target.value)} className="w-56" />
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button><Plus className="mr-2 h-4 w-4" />List business</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>List your business</DialogTitle></DialogHeader>
              <form className="space-y-3" onSubmit={(e) => {
                e.preventDefault();
                const fd = new FormData(e.currentTarget);
                create.mutate(Object.fromEntries(fd) as Record<string, string>);
              }}>
                <div><Label>Name</Label><Input name="name" required /></div>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label>Category</Label><Input name="category" required placeholder="Grocery, Salon…" /></div>
                  <div><Label>Area</Label><Input name="area" /></div>
                </div>
                <div><Label>Phone</Label><Input name="phone" /></div>
                <div><Label>Address</Label><Input name="address" /></div>
                <div><Label>Description</Label><Textarea name="description" rows={3} /></div>
                <Button type="submit" className="w-full" disabled={create.isPending}>Add</Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {filtered?.map((b) => (
          <Card key={b.id}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">{b.name}</CardTitle>
                <Badge variant="secondary">{b.category}</Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-2 text-sm text-muted-foreground">
              {b.description && <p>{b.description}</p>}
              {b.phone && <p className="flex items-center gap-2"><Phone className="h-3.5 w-3.5" />{b.phone}</p>}
              {(b.address || b.area) && <p className="flex items-center gap-2"><MapPin className="h-3.5 w-3.5" />{[b.address, b.area].filter(Boolean).join(", ")}</p>}
            </CardContent>
          </Card>
        ))}
        {filtered?.length === 0 && <p className="text-muted-foreground">No businesses found.</p>}
      </div>
    </div>
  );
}