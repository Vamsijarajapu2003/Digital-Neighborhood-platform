import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus } from "lucide-react";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";

export const Route = createFileRoute("/_authenticated/complaints")({
  head: () => ({ meta: [{ title: "Complaints — Mera Ilaka" }] }),
  component: Complaints,
});

const statusColor: Record<string, string> = {
  open: "bg-accent text-accent-foreground",
  in_progress: "bg-secondary text-secondary-foreground",
  resolved: "bg-primary text-primary-foreground",
  closed: "bg-muted text-muted-foreground",
};

function Complaints() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);

  const { data } = useQuery({
    queryKey: ["complaints"],
    queryFn: async () => {
      const { data, error } = await supabase.from("complaints").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const create = useMutation({
    mutationFn: async (p: Record<string, string>) => {
      const { data: u } = await supabase.auth.getUser();
      const { error } = await supabase.from("complaints").insert({
        user_id: u.user!.id,
        title: p.title, description: p.description,
        category: p.category || null, area: p.area || null,
      });
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Complaint submitted"); qc.invalidateQueries({ queryKey: ["complaints"] }); setOpen(false); },
    onError: (e) => toast.error(e.message),
  });

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Complaints</h1>
          <p className="text-muted-foreground">Raise civic issues and track their status.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button><Plus className="mr-2 h-4 w-4" />New complaint</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Submit complaint</DialogTitle></DialogHeader>
            <form className="space-y-3" onSubmit={(e) => {
              e.preventDefault();
              const fd = new FormData(e.currentTarget);
              create.mutate(Object.fromEntries(fd) as Record<string, string>);
            }}>
              <div><Label>Title</Label><Input name="title" required /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Category</Label><Input name="category" placeholder="Water, Roads…" /></div>
                <div><Label>Area</Label><Input name="area" /></div>
              </div>
              <div><Label>Description</Label><Textarea name="description" required rows={4} /></div>
              <Button type="submit" className="w-full" disabled={create.isPending}>Submit</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="space-y-3">
        {data?.map((c) => (
          <Card key={c.id}>
            <CardHeader>
              <div className="flex items-start justify-between gap-2">
                <CardTitle className="text-lg">{c.title}</CardTitle>
                <Badge className={statusColor[c.status] ?? ""}>{c.status.replace("_", " ")}</Badge>
              </div>
              <p className="text-xs text-muted-foreground">
                {[c.category, c.area].filter(Boolean).join(" • ")}{c.category || c.area ? " • " : ""}
                {formatDistanceToNow(new Date(c.created_at), { addSuffix: true })}
              </p>
            </CardHeader>
            <CardContent><p className="whitespace-pre-wrap text-sm">{c.description}</p></CardContent>
          </Card>
        ))}
        {data?.length === 0 && <p className="text-muted-foreground">No complaints yet.</p>}
      </div>
    </div>
  );
}