import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Megaphone, Store, ShoppingBag, Calendar, MessageSquareWarning } from "lucide-react";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — Mera Ilaka" }] }),
  component: Dashboard,
});

function useCount(table: "announcements" | "businesses" | "marketplace_items" | "events" | "complaints") {
  return useQuery({
    queryKey: ["count", table],
    queryFn: async () => {
      const { count, error } = await supabase.from(table).select("*", { count: "exact", head: true });
      if (error) throw error;
      return count ?? 0;
    },
  });
}

function Dashboard() {
  const stats = [
    { table: "announcements" as const, label: "Announcements", icon: Megaphone, to: "/announcements" },
    { table: "businesses" as const, label: "Businesses", icon: Store, to: "/businesses" },
    { table: "marketplace_items" as const, label: "Marketplace", icon: ShoppingBag, to: "/marketplace" },
    { table: "events" as const, label: "Events", icon: Calendar, to: "/events" },
    { table: "complaints" as const, label: "Complaints", icon: MessageSquareWarning, to: "/complaints" },
  ];
  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Welcome back</h1>
        <p className="text-muted-foreground">Here's what's happening in your ilaka.</p>
      </div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        {stats.map((s) => <StatCard key={s.table} {...s} />)}
      </div>
    </div>
  );
}

function StatCard({ table, label, icon: Icon, to }: { table: Parameters<typeof useCount>[0]; label: string; icon: typeof Megaphone; to: string }) {
  const { data, isLoading } = useCount(table);
  return (
    <Link to={to}>
      <Card className="transition-shadow hover:shadow-md">
        <CardHeader className="flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">{label}</CardTitle>
          <Icon className="h-4 w-4 text-accent" />
        </CardHeader>
        <CardContent><div className="text-3xl font-bold">{isLoading ? "—" : data}</div></CardContent>
      </Card>
    </Link>
  );
}