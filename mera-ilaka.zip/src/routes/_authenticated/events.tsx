import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, MapPin, CalendarDays } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";

export const Route = createFileRoute("/_authenticated/events")({
  head: () => ({ meta: [{ title: "Events — Mera Ilaka" }] }),
  component: Events,
});

function Events() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);

  useEffect(() => { supabase.auth.getUser().then(({ data }) => setUserId(data.user?.id ?? null)); }, []);

  const { data: events } = useQuery({
    queryKey: ["events"],
    queryFn: async () => {
      const { data, error } = await supabase.from("events").select("*").order("starts_at", { ascending: true });
      if (error) throw error;
      return data;
    },
  });
  const { data: rsvps } = useQuery({
    queryKey: ["event_rsvps"],
    queryFn: async () => {
      const { data, error } = await supabase.from("event_rsvps").select("*");
      if (error) throw error;
      return data;
    },
  });

  const create = useMutation({
    mutationFn: async (p: Record<string, string>) => {
      const { data: u } = await supabase.auth.getUser();
      const { error } = await supabase.from("events").insert({
        organizer_id: u.user!.id, title: p.title, description: p.description,
        location: p.location, starts_at: new Date(p.starts_at).toISOString(),
      });
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Event created"); qc.invalidateQueries({ queryKey: ["events"] }); setOpen(false); },
    onError: (e) => toast.error(e.message),
  });

  const toggleRsvp = useMutation({
    mutationFn: async ({ eventId, joined }: { eventId: string; joined: boolean }) => {
      if (joined) {
        const { error } = await supabase.from("event_rsvps").delete().eq("event_id", eventId).eq("user_id", userId!);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("event_rsvps").insert({ event_id: eventId, user_id: userId! });
        if (error) throw error;
      }
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["event_rsvps"] }),
    onError: (e) => toast.error(e.message),
  });

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Events</h1>
          <p className="text-muted-foreground">Join or organize community events.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button><Plus className="mr-2 h-4 w-4" />Create event</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Create event</DialogTitle></DialogHeader>
            <form className="space-y-3" onSubmit={(e) => {
              e.preventDefault();
              const fd = new FormData(e.currentTarget);
              create.mutate(Object.fromEntries(fd) as Record<string, string>);
            }}>
              <div><Label>Title</Label><Input name="title" required /></div>
              <div><Label>Location</Label><Input name="location" /></div>
              <div><Label>Starts at</Label><Input name="starts_at" type="datetime-local" required /></div>
              <div><Label>Description</Label><Textarea name="description" rows={3} /></div>
              <Button type="submit" className="w-full" disabled={create.isPending}>Create</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {events?.map((ev) => {
          const attendees = rsvps?.filter((r) => r.event_id === ev.id) ?? [];
          const joined = attendees.some((r) => r.user_id === userId);
          return (
            <Card key={ev.id}>
              <CardHeader>
                <CardTitle>{ev.title}</CardTitle>
                <div className="mt-1 space-y-1 text-xs text-muted-foreground">
                  <p className="flex items-center gap-2"><CalendarDays className="h-3.5 w-3.5" />{format(new Date(ev.starts_at), "PPp")}</p>
                  {ev.location && <p className="flex items-center gap-2"><MapPin className="h-3.5 w-3.5" />{ev.location}</p>}
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {ev.description && <p className="text-sm text-muted-foreground">{ev.description}</p>}
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">{attendees.length} going</span>
                  <Button size="sm" variant={joined ? "secondary" : "default"}
                    onClick={() => toggleRsvp.mutate({ eventId: ev.id, joined })}>
                    {joined ? "Cancel RSVP" : "RSVP"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
        {events?.length === 0 && <p className="text-muted-foreground">No events yet.</p>}
      </div>
    </div>
  );
}