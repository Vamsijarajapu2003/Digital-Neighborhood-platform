import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/marketplace")({
  head: () => ({ meta: [{ title: "Marketplace — Mera Ilaka" }] }),
  component: Marketplace,
});

function Marketplace() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);

  const { data } = useQuery({
    queryKey: ["marketplace_items"],
    queryFn: async () => {
      const { data, error } = await supabase.from("marketplace_items").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const create = useMutation({
    mutationFn: async (p: { title: string; description: string; price: string; category: string }) => {
      const { data: u } = await supabase.auth.getUser();
      const { error } = await supabase.from("marketplace_items").insert({
        seller_id: u.user!.id, title: p.title, description: p.description,
        price: Number(p.price) || 0, category: p.category,
      });
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Item posted"); qc.invalidateQueries({ queryKey: ["marketplace_items"] }); setOpen(false); },
    onError: (e) => toast.error(e.message),
  });

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Marketplace</h1>
          <p className="text-muted-foreground">Buy and sell within your neighborhood.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button><Plus className="mr-2 h-4 w-4" />Post item</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Post an item</DialogTitle></DialogHeader>
            <form className="space-y-3" onSubmit={(e) => {
              e.preventDefault();
              const fd = new FormData(e.currentTarget);
              create.mutate({
                title: String(fd.get("title")), description: String(fd.get("description")),
                price: String(fd.get("price")), category: String(fd.get("category")),
              });
            }}>
              <div><Label>Title</Label><Input name="title" required /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Price (₹)</Label><Input name="price" type="number" min="0" step="0.01" required /></div>
                <div><Label>Category</Label><Input name="category" /></div>
              </div>
              <div><Label>Description</Label><Textarea name="description" rows={3} /></div>
              <Button type="submit" className="w-full" disabled={create.isPending}>Post</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {data?.map((i) => (
          <Card key={i.id}>
            <CardHeader>
              <div className="flex items-start justify-between gap-2">
                <CardTitle className="text-lg">{i.title}</CardTitle>
                {i.is_sold && <Badge variant="secondary">Sold</Badge>}
              </div>
              <p className="text-2xl font-bold text-accent">₹{Number(i.price).toLocaleString()}</p>
            </CardHeader>
            <CardContent className="text-sm text-muted-foreground">
              {i.category && <Badge variant="outline" className="mb-2">{i.category}</Badge>}
              {i.description && <p>{i.description}</p>}
            </CardContent>
          </Card>
        ))}
        {data?.length === 0 && <p className="text-muted-foreground">No items yet.</p>}
      </div>
    </div>
  );
}