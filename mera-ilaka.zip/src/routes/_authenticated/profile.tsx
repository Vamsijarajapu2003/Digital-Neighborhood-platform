import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/profile")({
  head: () => ({ meta: [{ title: "Profile — Mera Ilaka" }] }),
  component: Profile,
});

function Profile() {
  const qc = useQueryClient();
  const { data } = useQuery({
    queryKey: ["me"],
    queryFn: async () => {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) return null;
      const { data: p, error } = await supabase.from("profiles").select("*").eq("id", u.user.id).maybeSingle();
      if (error) throw error;
      return { user: u.user, profile: p };
    },
  });

  const save = useMutation({
    mutationFn: async (p: Record<string, string>) => {
      const { data: u } = await supabase.auth.getUser();
      const { error } = await supabase.from("profiles").upsert({ id: u.user!.id, ...p });
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Profile saved"); qc.invalidateQueries({ queryKey: ["me"] }); },
    onError: (e) => toast.error(e.message),
  });

  if (!data) return <p className="text-muted-foreground">Loading…</p>;
  const p = data.profile;

  return (
    <div className="mx-auto max-w-2xl">
      <Card>
        <CardHeader>
          <CardTitle>Your profile</CardTitle>
          <p className="text-sm text-muted-foreground">{data.user.email}</p>
        </CardHeader>
        <CardContent>
          <form className="space-y-3" onSubmit={(e) => {
            e.preventDefault();
            const fd = new FormData(e.currentTarget);
            save.mutate(Object.fromEntries(fd) as Record<string, string>);
          }}>
            <div><Label>Full name</Label><Input name="full_name" defaultValue={p?.full_name ?? ""} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Phone</Label><Input name="phone" defaultValue={p?.phone ?? ""} /></div>
              <div><Label>Area</Label><Input name="area" defaultValue={p?.area ?? ""} /></div>
            </div>
            <div><Label>Address</Label><Textarea name="address" rows={2} defaultValue={p?.address ?? ""} /></div>
            <Button type="submit" disabled={save.isPending}>Save</Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}