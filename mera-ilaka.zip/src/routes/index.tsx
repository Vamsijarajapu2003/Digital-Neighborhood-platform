import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Megaphone, Store, ShoppingBag, Calendar, MessageSquareWarning, Users } from "lucide-react";

export const Route = createFileRoute("/")({
  component: Landing,
});

const features = [
  { icon: Megaphone, title: "Announcements", desc: "Stay updated on notices from your area." },
  { icon: Store, title: "Business Directory", desc: "Discover trusted local shops and services." },
  { icon: ShoppingBag, title: "Marketplace", desc: "Buy and sell within your neighborhood." },
  { icon: Calendar, title: "Events", desc: "Join community meetups and celebrations." },
  { icon: MessageSquareWarning, title: "Complaints", desc: "Raise civic issues and track resolution." },
  { icon: Users, title: "Community", desc: "Connect with residents, businesses and authorities." },
];

function Landing() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b border-border">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-2">
            <div className="grid h-9 w-9 place-items-center rounded-lg bg-primary text-primary-foreground font-bold">MI</div>
            <span className="text-lg font-semibold">Mera Ilaka</span>
          </div>
          <div className="flex items-center gap-2">
            <Link to="/auth"><Button variant="ghost">Sign in</Button></Link>
            <Link to="/auth"><Button>Get started</Button></Link>
          </div>
        </div>
      </header>

      <section className="mx-auto max-w-6xl px-6 py-20 text-center">
        <h1 className="text-5xl font-bold tracking-tight md:text-6xl">
          Your neighborhood, <span className="text-accent">reimagined</span>.
        </h1>
        <p className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground">
          Mera Ilaka brings residents, businesses, service providers and local authorities
          onto one simple platform — announcements, marketplace, events, and complaints in one place.
        </p>
        <div className="mt-8 flex justify-center gap-3">
          <Link to="/auth"><Button size="lg">Join your ilaka</Button></Link>
          <Link to="/dashboard"><Button size="lg" variant="outline">Explore dashboard</Button></Link>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 pb-24">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {features.map((f) => (
            <div key={f.title} className="rounded-2xl border border-border bg-card p-6 shadow-sm">
              <div className="mb-4 grid h-11 w-11 place-items-center rounded-lg bg-secondary text-secondary-foreground">
                <f.icon className="h-5 w-5" />
              </div>
              <h3 className="text-lg font-semibold">{f.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="border-t border-border">
        <div className="mx-auto max-w-6xl px-6 py-6 text-sm text-muted-foreground">
          © {new Date().getFullYear()} Mera Ilaka — a digital neighborhood platform.
        </div>
      </footer>
    </div>
  );
}
